﻿using System;
using System.IO;
using System.Net.Sockets;

namespace ChatClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string serverIP = "127.0.0.1";
            int port = 1308;

            while (true)
            {
                Console.Write("Nhap lenh (calc/check/exit): ");
                string request = Console.ReadLine();
                if (request.ToLower() == "exit") break;

                using (var socket = new TcpClient(serverIP, port))
                using (var stream = socket.GetStream())
                using (var reader = new StreamReader(stream))
                using (var writer = new StreamWriter(stream))
                {
                    writer.AutoFlush = true;
                    writer.WriteLine(request);

                    string response = reader.ReadLine();
                    Console.WriteLine($"Server tra: {response}");
                }
            }
        }
    }
}
