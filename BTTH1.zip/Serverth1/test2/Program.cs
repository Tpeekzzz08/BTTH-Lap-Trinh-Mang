﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ChatServer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int port = 1308;
            var listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            Console.WriteLine("Server started...");

            while (true)
            {
                var client = listener.AcceptTcpClient();
                Thread t = new Thread(HandleClient);
                t.Start(client);
            }
        }

        static void HandleClient(object obj)
        {
            var client = (TcpClient)obj;
            using (var stream = client.GetStream())
            using (var reader = new StreamReader(stream))
            using (var writer = new StreamWriter(stream))
            {
                writer.AutoFlush = true;
                try
                {
                    string request = reader.ReadLine();
                    Console.WriteLine($"Client gui: {request}");

                    string response = ProcessRequest(request);
                    writer.WriteLine(response);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }

        static string ProcessRequest(string request)
        {
            // VD: "calc 5+3" hoặc "check 7"
            if (request.StartsWith("calc"))
            {
                string expr = request.Substring(5); // bỏ "calc "
                try
                {
                    var result = Evaluate(expr);
                    return $"Ket qua: {result}";
                }
                catch
                {
                    return "Loi phep tinh!";
                }
            }
            else if (request.StartsWith("check"))
            {
                if (int.TryParse(request.Substring(6), out int number))
                {
                    if (IsPrime(number)) return $"{number} la so nguyen to";
                    else if (number % 2 == 0) return $"{number} la so chan";
                    else return $"{number} la so le";
                }
                return "Khong phai so hop le!";
            }
            return "Lenh khong hop le!";
        }

        static double Evaluate(string expr)
        {
            // Đơn giản: chỉ hỗ trợ số và + - * /
            var dt = new System.Data.DataTable();
            return Convert.ToDouble(dt.Compute(expr, ""));
        }

        static bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0) return false;
            return true;
        }
    }
}
