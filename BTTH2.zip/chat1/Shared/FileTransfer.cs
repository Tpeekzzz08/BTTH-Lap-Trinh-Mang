using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RealtimeChatShared
{
    public static class FileTransfer
    {
        // Đảm bảo đọc đúng số byte
        public static async Task ReadExactlyAsync(NetworkStream ns, byte[] buffer, int offset, int count, CancellationToken ct = default)
        {
            int read = 0;
            while (read < count)
            {
                int n = await ns.ReadAsync(buffer, offset + read, count - read, ct);
                if (n == 0) throw new IOException("Socket closed while reading.");
                read += n;
            }
        }

        // Gửi file: gửi header (len-prefixed) rồi gửi nội dung file
        public static async Task SendFileAsync(NetworkStream ns, string filePath, CancellationToken ct = default)
        {
            var fi = new FileInfo(filePath);
            long length = fi.Length;
            string fileName = fi.Name;

            var headerObj = new
            {
                Type = "FILE",
                FileName = fileName,
                Length = length
            };

            string headerJson = JsonSerializer.Serialize(headerObj);
            byte[] headerBytes = Encoding.UTF8.GetBytes(headerJson);
            byte[] headerLen = BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(headerBytes.Length));

            // send header length + header
            await ns.WriteAsync(headerLen, 0, headerLen.Length, ct);
            await ns.WriteAsync(headerBytes, 0, headerBytes.Length, ct);
            await ns.FlushAsync(ct);

            // send file bytes in chunks
            const int CHUNK = 64 * 1024;
            byte[] buffer = new byte[CHUNK];
            using var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            int read;
            while ((read = await fs.ReadAsync(buffer, 0, buffer.Length, ct)) > 0)
            {
                await ns.WriteAsync(buffer, 0, read, ct);
            }
            await ns.FlushAsync(ct);
        }

        // Nhận file: headerJson phải được bên caller cung cấp (vì caller đã đọc header trước)
        public static async Task<string> ReceiveFileAsync(NetworkStream ns, string headerJson, string destFolder, CancellationToken ct = default)
        {
            // Parse header
            using var doc = JsonDocument.Parse(headerJson);
            var root = doc.RootElement;
            if (!root.TryGetProperty("FileName", out var nameEl) || !root.TryGetProperty("Length", out var lenEl))
                throw new InvalidDataException("Invalid file header.");

            string fileName = nameEl.GetString() ?? "received.bin";
            long length = lenEl.GetInt64();

            Directory.CreateDirectory(destFolder);
            string outPath = Path.Combine(destFolder, fileName);

            const int CHUNK = 64 * 1024;
            byte[] buffer = new byte[CHUNK];

            long remaining = length;
            using var fs = new FileStream(outPath, FileMode.Create, FileAccess.Write, FileShare.None);
            while (remaining > 0)
            {
                int toRead = (int)Math.Min(CHUNK, remaining);
                await ReadExactlyAsync(ns, buffer, 0, toRead, ct);
                await fs.WriteAsync(buffer, 0, toRead, ct);
                remaining -= toRead;
            }

            await fs.FlushAsync(ct);
            return outPath;
        }
    }
}
