using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientApp
{
    public class MainForm : Form
    {
        TextBox txtIP;
        TextBox txtPort;
        TextBox txtUsername;
        Button btnConnect;
        RichTextBox rtbLog;
        TextBox txtMessage;
        Button btnSend;
        Button btnPrivate;
        Button btnEmoji;
        Button btnSendFile;

        ListBox listBoxUsers;

        TcpClient client;
        NetworkStream stream;
        CancellationTokenSource cts = new CancellationTokenSource();

        // Track selected private target
        string selectedPrivateTarget = null;

        public MainForm()
        {
            this.Text = "Client Chat + File Transfer";
            this.Width = 980;
            this.Height = 600;
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponents();
        }

        void InitializeComponents()
        {
            var lblIP = new Label() { Left = 20, Top = 18, Text = "IP:", Width = 25 };
            txtIP = new TextBox() { Left = 50, Top = 15, Width = 150, Text = "127.0.0.1" };
            var lblPort = new Label() { Left = 210, Top = 18, Text = "Port:", Width = 40 };
            txtPort = new TextBox() { Left = 250, Top = 15, Width = 60, Text = "9000" };

            var lblUser = new Label() { Left = 320, Top = 18, Text = "Username:", Width = 70 };
            txtUsername = new TextBox() { Left = 400, Top = 15, Width = 120, Text = "Client" + new Random().Next(1000, 9999) };

            btnConnect = new Button() { Left = 530, Top = 12, Width = 90, Text = "Connect" };

            rtbLog = new RichTextBox()
            {
                Left = 20,
                Top = 60,
                Width = 740,
                Height = 420,
                ReadOnly = true
            };

            txtMessage = new TextBox() { Left = 20, Top = 490, Width = 430, Height = 25 };

            btnSend = new Button() { Left = 460, Top = 488, Width = 70, Height = 30, Text = "Send" };
            btnPrivate = new Button() { Left = 540, Top = 488, Width = 70, Height = 30, Text = "Private" };
            btnEmoji = new Button() { Left = 620, Top = 488, Width = 50, Height = 30, Text = "😊" };
            btnSendFile = new Button() { Left = 680, Top = 488, Width = 80, Height = 30, Text = "📁 File" };

            listBoxUsers = new ListBox()
            {
                Left = 780,
                Top = 60,
                Width = 160,
                Height = 420
            };

            var lblUsers = new Label()
            {
                Left = 780,
                Top = 30,
                Text = "Online users:",
                Width = 160
            };

            this.Controls.AddRange(new Control[]
            {
                lblIP, txtIP, lblPort, txtPort, lblUser, txtUsername, btnConnect,
                rtbLog, txtMessage, btnSend, btnPrivate, btnEmoji, btnSendFile,
                listBoxUsers, lblUsers
            });

            btnConnect.Click += BtnConnect_Click;
            btnSend.Click += BtnSend_Click;
            btnPrivate.Click += BtnPrivate_Click;
            btnEmoji.Click += BtnEmoji_Click;
            btnSendFile.Click += BtnSendFile_Click;

            listBoxUsers.DoubleClick += ListBoxUsers_DoubleClick;

            // Enter to send (normal or private)
            txtMessage.KeyDown += TxtMessage_KeyDown;
        }

        private void ListBoxUsers_DoubleClick(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedItem != null)
            {
                selectedPrivateTarget = listBoxUsers.SelectedItem.ToString();
                txtMessage.Text = ""; // clear so user types fresh
                Log($"[System] Private target selected: {selectedPrivateTarget}");
                txtMessage.Focus();
            }
        }

        private void TxtMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (!string.IsNullOrEmpty(selectedPrivateTarget))
                    BtnPrivate_Click(null, null);
                else
                    BtnSend_Click(null, null);
            }
        }

        private void BtnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Text == "Connect")
            {
                try
                {
                    client = new TcpClient();
                    client.Connect(txtIP.Text, int.Parse(txtPort.Text));
                    stream = client.GetStream();

                    Log($"[Client] Connected to {txtIP.Text}:{txtPort.Text}");
                    btnConnect.Text = "Disconnect";

                    cts = new CancellationTokenSource();

                    // gửi login
                    SendRawJson(new
                    {
                        type = "login",
                        username = txtUsername.Text
                    });

                    Task.Run(() => ReceiveLoopAsync(stream, cts.Token));
                }
                catch (Exception ex)
                {
                    Error("Connect", ex);
                }
            }
            else
            {
                StopConnection();
            }
        }

        private async void ReceiveLoopAsync(NetworkStream ns, CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    byte[] lenBuf = new byte[4];
                    int readLen = await FileTransfer.ReadExactlyAsync(ns, lenBuf, 0, 4, token);
                    if (readLen < 4) break;

                    int payloadLen = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(lenBuf, 0));
                    if (payloadLen <= 0) continue;

                    byte[] payloadBuf = new byte[payloadLen];
                    int got = await FileTransfer.ReadExactlyAsync(ns, payloadBuf, 0, payloadLen, token);
                    if (got < payloadLen) break;

                    // parse JSON directly from bytes to avoid issues when binary follows header
                    using (var doc = JsonDocument.Parse(payloadBuf))
                    {
                        var root = doc.RootElement;
                        string type = root.GetProperty("type").GetString() ?? "";

                        if (type == "userlist")
                        {
                            var arr = root.GetProperty("users");
                            Invoke(new Action(() =>
                            {
                                listBoxUsers.Items.Clear();
                                foreach (var u in arr.EnumerateArray())
                                {
                                    string user = u.GetString();
                                    if (user != txtUsername.Text)
                                        listBoxUsers.Items.Add(user);
                                }
                                Log("[System] User list updated.");
                            }));
                        }
                        else if (type == "chat")
                        {
                            string from = root.GetProperty("from").GetString();
                            string to = root.GetProperty("to").GetString();
                            string msg = root.GetProperty("message").GetString();

                            if (to == "ALL")
                                Log($"{from}: {msg}");
                            else
                                Log($"[PRIVATE] {from} → {to}: {msg}");
                        }
                        else if (type == "file")
                        {
                            string fileName = root.GetProperty("fileName").GetString();
                            long fileSize = root.GetProperty("fileSize").GetInt64();

                            string saveDir = Path.Combine(
                                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                                "Client_files"
                            );

                            Directory.CreateDirectory(saveDir);
                            string savePath = Path.Combine(saveDir, $"{DateTime.Now:yyyyMMdd_HHmmss}_{fileName}");

                            using (var fs = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))

                            {
                                long remain = fileSize;
                                byte[] buffer = new byte[8192];

                                while (remain > 0)
                                {
                                    int toRead = (int)Math.Min(buffer.Length, remain);
                                    int r = await FileTransfer.ReadExactlyAsync(ns, buffer, 0, toRead, token);
                                    if (r <= 0) break;

                                    await fs.WriteAsync(buffer, 0, r);
                                    remain -= r;
                                }
                            }

                            Log($"[FILE] Saved: {savePath}");
                        }
                        else if (type == "system")
                        {
                            string m = root.GetProperty("message").GetString();
                            Log($"[System] {m}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Error("ReceiveLoop", ex);
            }
            finally
            {
                Invoke(new Action(() => btnConnect.Text = "Connect"));
            }
        }

        private void BtnSend_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMessage.Text)) return;

            var json = new
            {
                type = "chat",
                from = txtUsername.Text,
                to = "ALL",
                message = txtMessage.Text.Trim()
            };

            SendRawJson(json);
            Log($"Me: {txtMessage.Text}");
            txtMessage.Clear();
        }

        private void BtnPrivate_Click(object sender, EventArgs e)
        {
            string to = selectedPrivateTarget ?? (listBoxUsers.SelectedItem != null ? listBoxUsers.SelectedItem.ToString() : null);

            if (string.IsNullOrEmpty(to))
            {
                MessageBox.Show("Select a user to chat privately.");
                return;
            }

            // Ensure chosen user is still online
            bool online = false;
            for (int i = 0; i < listBoxUsers.Items.Count; i++)
            {
                if ((string)listBoxUsers.Items[i] == to)
                {
                    online = true; break;
                }
            }

            if (!online)
            {
                MessageBox.Show("User appears to be offline.");
                selectedPrivateTarget = null;
                return;
            }

            string msg = txtMessage.Text.Trim();
            if (msg.Length == 0) return;

            var json = new
            {
                type = "chat",
                from = txtUsername.Text,
                to = to,
                message = msg
            };

            SendRawJson(json);
            Log($"Me → {to} (private): {msg}");
            txtMessage.Clear();
            // keep private target so user can continue private conversation
            txtMessage.Focus();
        }

        private async void BtnSendFile_Click(object sender, EventArgs e)
        {
            if (stream == null)
            {
                MessageBox.Show("Connect first!");
                return;
            }

            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() != DialogResult.OK) return;

                string file = ofd.FileName;
                string fileName = Path.GetFileName(file);
                long fileSize = new FileInfo(file).Length;

                // --- xác định người nhận
                string to = selectedPrivateTarget ??
                            (listBoxUsers.SelectedItem?.ToString() ?? "ALL");

                var header = new
                {
                    type = "file",
                    from = txtUsername.Text,
                    to = to,
                    fileName = fileName,
                    fileSize = fileSize
                };

                try
                {
                    // 1) gửi header có length prefix
                    await SendRawJsonAsync(header);

                    // 2) gửi dữ liệu file
                    using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read))
                    {
                        byte[] buffer = new byte[8192];
                        int r;

                        while ((r = await fs.ReadAsync(buffer, 0, buffer.Length)) > 0)
                        {
                            await stream.WriteAsync(buffer, 0, r);
                            await stream.FlushAsync();   // 💥 FIX LỖI QUAN TRỌNG
                        }
                    }

                    Log($"[FILE] Sent {fileName} → {to}");
                }
                catch (Exception ex)
                {
                    Log("[ERROR] While sending file: " + ex.Message);
                }
            }
        }


        private void BtnEmoji_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Emoji picker not included here but can be added easily.");
        }

        void SendRawJson(object obj)
        {
            if (stream == null) return;

            string json = JsonSerializer.Serialize(obj);
            byte[] data = Encoding.UTF8.GetBytes(json);
            byte[] len = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(data.Length));

            try
            {
                stream.Write(len, 0, 4);
                stream.Write(data, 0, data.Length);
                stream.Flush();
            }
            catch (Exception ex)
            {
                Error("SendRawJson", ex);
            }
        }

        async Task SendRawJsonAsync(object obj)
        {
            if (stream == null) return;

            string json = JsonSerializer.Serialize(obj);
            byte[] data = Encoding.UTF8.GetBytes(json);
            byte[] len = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(data.Length));

            await stream.WriteAsync(len, 0, 4);
            await stream.WriteAsync(data, 0, data.Length);
        }

        void StopConnection()
        {
            try
            {
                cts.Cancel();
                stream?.Close();
                client?.Close();
                Log("[System] Disconnected.");
            }
            catch { }

            btnConnect.Text = "Connect";
            selectedPrivateTarget = null;
        }

        void Log(string text)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(Log), text);
                return;
            }
            rtbLog.AppendText(text + Environment.NewLine);
        }

        void Error(string where, Exception ex)
        {
            Log($"[ERROR] {where}: {ex.Message}");
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            StopConnection();
            base.OnFormClosing(e);
        }

        static class FileTransfer
        {
            public static async Task<int> ReadExactlyAsync(Stream s, byte[] buffer, int offset, int count, CancellationToken token)
            {
                int total = 0;
                while (total < count)
                {
                    int r = await s.ReadAsync(buffer, offset + total, count - total, token);
                    if (r == 0) return total;
                    total += r;
                }
                return total;
            }
        }
    }
}
