using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace ServerApp
{
    public class ServerMainForm : Form
    {
        RadioButton rbServer;
        RadioButton rbClient;
        TextBox txtIP;
        TextBox txtPort;
        TextBox txtUsername;
        Button btnStart;

        RichTextBox logBox;
        TextBox txtMessage;
        Button btnSend;

        // Network
        TcpListener listener;
        TcpClient localClient;
        CancellationTokenSource cts;

        // Active clients
        ConcurrentDictionary<string, TcpClient> clients = new ConcurrentDictionary<string, TcpClient>();
        ConcurrentDictionary<TcpClient, string> clientNames = new ConcurrentDictionary<TcpClient, string>();

        bool IsServer => rbServer.Checked;

        public ServerMainForm()
        {
            this.Text = "Realtime Chat (Server/Client) + File Transfer (Server)";
            this.Width = 780;
            this.Height = 560;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new System.Drawing.Size(640, 420);
            this.Padding = new Padding(8);
            this.AutoScaleMode = AutoScaleMode.Dpi;

            InitializeComponents();
        }

        // ----------------------------
        // UI FIXED USING TABLELAYOUT
        // ----------------------------
        void InitializeComponents()
        {
            // Top container: table layout with auto sizing columns
            var topTable = new TableLayoutPanel()
            {
                Dock = DockStyle.Top,
                Height = 48,
                ColumnCount = 11,
                RowCount = 1,
                AutoSize = false,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };

            // define column widths (some are autosize, some percent)
            topTable.ColumnStyles.Clear();
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // rbServer
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // rbClient
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 12)); // spacer
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // lblIP
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30)); // txtIP
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // lblPort
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70)); // txtPort (fixed small)
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // lblUser
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40)); // txtUsername
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 12)); // spacer
            topTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); // btnStart

            // Controls
            rbServer = new RadioButton() { Text = "Server", Anchor = AnchorStyles.Left, AutoSize = true, Checked = true };
            rbClient = new RadioButton() { Text = "Client", Anchor = AnchorStyles.Left, AutoSize = true };

            var lblIP = new Label() { Text = "IP:", Anchor = AnchorStyles.Right, AutoSize = true, TextAlign = System.Drawing.ContentAlignment.MiddleRight };
            txtIP = new TextBox() { Text = "127.0.0.1", Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = new Padding(3, 10, 3, 10) };

            var lblPort = new Label() { Text = "Port:", Anchor = AnchorStyles.Right, AutoSize = true, TextAlign = System.Drawing.ContentAlignment.MiddleRight };
            txtPort = new TextBox() { Text = "9000", Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = new Padding(3, 10, 3, 10) };

            var lblUser = new Label() { Text = "Username:", Anchor = AnchorStyles.Right, AutoSize = true, TextAlign = System.Drawing.ContentAlignment.MiddleRight };
            txtUsername = new TextBox() { Text = "Server", Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = new Padding(3, 10, 3, 10) };

            btnStart = new Button() { Text = "Start", AutoSize = true, Anchor = AnchorStyles.Right, Margin = new Padding(6, 8, 6, 8) };
            btnStart.Click += BtnStart_Click;

            // add controls to table
            topTable.Controls.Add(rbServer, 0, 0);
            topTable.Controls.Add(rbClient, 1, 0);
            topTable.Controls.Add(lblIP, 3, 0);
            topTable.Controls.Add(txtIP, 4, 0);
            topTable.Controls.Add(lblPort, 5, 0);
            topTable.Controls.Add(txtPort, 6, 0);
            topTable.Controls.Add(lblUser, 7, 0);
            topTable.Controls.Add(txtUsername, 8, 0);
            topTable.Controls.Add(btnStart, 10, 0);

            // Make sure textboxes fill their percentage columns
            txtIP.Dock = DockStyle.Fill;
            txtUsername.Dock = DockStyle.Fill;
            txtPort.Dock = DockStyle.Fill;

            // Log area - fill remaining client area
            logBox = new RichTextBox()
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Bottom message panel
            var bottomPanel = new Panel()
            {
                Dock = DockStyle.Bottom,
                Height = 48,
                Padding = new Padding(0)
            };

            txtMessage = new TextBox()
            {
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom,
                Left = 8,
                Top = 8,
                Height = 32,
                Width = this.ClientSize.Width - 160,
            };

            btnSend = new Button()
            {
                Text = "Send",
                Width = 120,
                Height = 32,
                Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            btnSend.Click += BtnSend_Click;

            // Add controls to bottomPanel and adjust positions in Resize
            bottomPanel.Controls.Add(txtMessage);
            bottomPanel.Controls.Add(btnSend);
            bottomPanel.Resize += (s, e) =>
            {
                int pad = 8;
                int btnW = 120;
                txtMessage.Left = pad;
                txtMessage.Top = pad;
                txtMessage.Width = Math.Max(80, bottomPanel.ClientSize.Width - btnW - pad * 3);
                txtMessage.Height = bottomPanel.ClientSize.Height - pad * 2;

                btnSend.Left = txtMessage.Right + pad;
                btnSend.Top = pad;
                btnSend.Height = txtMessage.Height;
            };

            // Main container panel for log (so we can have padding)
            var mainPanel = new Panel()
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(8)
            };
            mainPanel.Controls.Add(logBox);

            // Overall form controls
            this.Controls.Add(mainPanel);
            this.Controls.Add(bottomPanel);
            this.Controls.Add(topTable);

            // Initial layout fix: trigger bottomPanel layout safely
            bottomPanel.PerformLayout();
            bottomPanel.Refresh();
            // removed invalid OnResize call
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            if (btnStart.Text == "Start")
            {
                btnStart.Text = "Stop";
                rbServer.Enabled = rbClient.Enabled = false;

                cts = new CancellationTokenSource();

                if (IsServer) StartServer();
                else StartClient();
            }
            else
            {
                StopAll();
            }
        }

        // =====================
        // SERVER MODE
        // =====================

        void StartServer()
        {
            try
            {
                int port = int.Parse(txtPort.Text);
                listener = new TcpListener(IPAddress.Any, port);
                listener.Start();

                Log($"[Server] Listening on port {port}");

                Task.Run(() => AcceptLoopAsync(cts.Token));
            }
            catch (Exception ex)
            {
                Error("StartServer", ex);
            }
        }

        async Task AcceptLoopAsync(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    TcpClient tcp = await listener.AcceptTcpClientAsync();
                    Log($"[Server] Client connected: {tcp.Client.RemoteEndPoint}");
                    _ = Task.Run(() => HandleClientAsync(tcp, token));
                }
            }
            catch (ObjectDisposedException) { }
            catch (Exception ex) { Error("AcceptLoop", ex); }
        }

        async Task HandleClientAsync(TcpClient tcp, CancellationToken token)
        {
            NetworkStream ns = tcp.GetStream();

            try
            {
                var loginObj = await ReadJsonObjectAsync(ns, token);
                if (loginObj == null || !loginObj.Value.TryGetProperty("username", out var uname))
                {
                    tcp.Close();
                    return;
                }

                string username = uname.GetString();
                if (string.IsNullOrWhiteSpace(username))
                {
                    tcp.Close();
                    return;
                }

                string original = username;
                int suffix = 1;
                while (clients.ContainsKey(username))
                {
                    username = original + "_" + suffix++;
                }

                clients[username] = tcp;
                clientNames[tcp] = username;

                Log($"[Server] User logged in: {username}");

                BroadcastUserList();
                BroadcastSystemMessage($"{username} joined the chat.");

                while (!token.IsCancellationRequested)
                {
                    byte[] lenBuf = new byte[4];
                    int readLen = await FileTransfer.ReadExactlyAsync(ns, lenBuf, 0, 4, token);
                    if (readLen < 4) break;

                    int payloadLen = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(lenBuf, 0));
                    if (payloadLen <= 0) continue;

                    byte[] payloadBuf = new byte[payloadLen];
                    int got = await FileTransfer.ReadExactlyAsync(ns, payloadBuf, 0, payloadLen, token);
                    if (got < payloadLen) break;

                    // parse JSON directly from bytes to avoid corruption when binary follows
                    using (var doc = JsonDocument.Parse(payloadBuf))
                    {
                        var root = doc.RootElement;
                        string type = root.GetProperty("type").GetString();

                        if (type == "chat")
                        {
                            string from = root.GetProperty("from").GetString();
                            string to = root.GetProperty("to").GetString();
                            string msg = root.GetProperty("message").GetString();

                            Log($"[Chat] {from} → {to}: {msg}");

                            await RouteChatMessageAsync(payloadBuf, to, from);
                        }
                        else if (type == "file")
                        {
                            string from = root.GetProperty("from").GetString();
                            string to = root.GetProperty("to").GetString();
                            string fileName = root.GetProperty("fileName").GetString();
                            long fileSize = root.GetProperty("fileSize").GetInt64();

                            Log($"[FILE] {from} → {to}: {fileName} ({fileSize} bytes)");

                            // send header to recipient(s)
                            await RouteFileHeaderAsync(payloadBuf, to, from);

                            // now read fileSize bytes from sender stream and relay to target(s)
                            await RelayFileAsync(ns, fileSize, to, from, token);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Error("HandleClient", ex);
            }
            finally
            {
                string username = null;
                if (clientNames.TryRemove(tcp, out username))
                {
                    clients.TryRemove(username, out _);
                    BroadcastUserList();
                    BroadcastSystemMessage($"{username} left the chat.");
                    Log($"[Server] {username} disconnected.");
                }

                try { tcp.Close(); } catch { }
            }
        }

        async Task RouteChatMessageAsync(byte[] rawMsg, string to, string from)
        {
            try
            {
                if (to == "ALL")
                {
                    foreach (var c in clients.Values)
                        await SendRawAsync(c, rawMsg);
                }
                else
                {
                    if (clients.TryGetValue(to, out var receiver))
                        await SendRawAsync(receiver, rawMsg);

                    if (clients.TryGetValue(from, out var sender))
                        await SendRawAsync(sender, rawMsg);
                }
            }
            catch { }
        }

        async Task RouteFileHeaderAsync(byte[] header, string to, string from)
        {
            try
            {
                if (to == "ALL")
                {
                    foreach (var c in clients.Values)
                        await SendRawAsync(c, header);
                }
                else
                {
                    if (clients.TryGetValue(to, out var receiver))
                        await SendRawAsync(receiver, header);

                    if (clients.TryGetValue(from, out var sender))
                        await SendRawAsync(sender, header);
                }
            }
            catch { }
        }

        async Task RelayFileAsync(NetworkStream senderNs, long fileSize, string to, string from, CancellationToken token)
        {
            try
            {
                List<NetworkStream> targets = new List<NetworkStream>();

                if (to == "ALL")
                {
                    foreach (var c in clients.Values)
                        targets.Add(c.GetStream());
                }
                else
                {
                    if (clients.TryGetValue(to, out var recv))
                        targets.Add(recv.GetStream());

                    if (clients.TryGetValue(from, out var sendBack))
                        targets.Add(sendBack.GetStream());
                }

                byte[] buffer = new byte[8192];
                long remaining = fileSize;

                while (remaining > 0)
                {
                    int toRead = (int)Math.Min(remaining, buffer.Length);
                    int r = await FileTransfer.ReadExactlyAsync(senderNs, buffer, 0, toRead, token);
                    if (r <= 0) break;

                    foreach (var ns in targets)
                    {
                        try
                        {
                            await ns.WriteAsync(buffer, 0, r, token);
                            await ns.FlushAsync(token);
                        }
                        catch { }
                    }

                    remaining -= r;
                }
            }
            catch { }
        }

        async Task SendRawAsync(TcpClient client, byte[] payload)
        {
            try
            {
                var ns = client.GetStream();
                byte[] len = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(payload.Length));
                await ns.WriteAsync(len, 0, 4);
                await ns.WriteAsync(payload, 0, payload.Length);
            }
            catch { }
        }

        async Task SendJsonAsync(TcpClient c, object obj)
        {
            try
            {
                string json = JsonSerializer.Serialize(obj);
                byte[] data = Encoding.UTF8.GetBytes(json);
                await SendRawAsync(c, data);
            }
            catch { }
        }

        void BroadcastUserList()
        {
            try
            {
                var usersSorted = clients.Keys.OrderBy(x => x).ToList();
                var json = new
                {
                    type = "userlist",
                    users = usersSorted
                };

                foreach (var c in clients.Values)
                    _ = SendJsonAsync(c, json);

                Log("[Server] User list updated");
            }
            catch { }
        }

        async void BroadcastSystemMessage(string message)
        {
            try
            {
                var obj = new
                {
                    type = "system",
                    message = message
                };

                foreach (var c in clients.Values)
                {
                    try
                    {
                        await SendJsonAsync(c, obj);
                    }
                    catch { }
                }

                Log("[Server] System: " + message);
            }
            catch { }
        }

        async Task<JsonElement?> ReadJsonObjectAsync(NetworkStream ns, CancellationToken token)
        {
            try
            {
                byte[] lenBuf = new byte[4];
                int r = await FileTransfer.ReadExactlyAsync(ns, lenBuf, 0, 4, token);
                if (r < 4) return null;

                int payloadLen = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(lenBuf, 0));
                if (payloadLen <= 0) return null;

                byte[] buf = new byte[payloadLen];
                int got = await FileTransfer.ReadExactlyAsync(ns, buf, 0, payloadLen, token);
                if (got < payloadLen) return null;

                using (var doc = JsonDocument.Parse(buf))
                {
                    return doc.RootElement.Clone();
                }
            }
            catch
            {
                return null;
            }
        }

        void StartClient()
        {
            try
            {
                localClient = new TcpClient();
                localClient.Connect(txtIP.Text, int.Parse(txtPort.Text));

                Log("[Client-Mode] Connected");
            }
            catch (Exception ex)
            {
                Error("StartClient", ex);
            }
        }

        void StopAll()
        {
            try
            {
                cts?.Cancel();
                listener?.Stop();

                foreach (var c in clients.Values)
                {
                    try { c.Close(); } catch { }
                }

                clients.Clear();
                clientNames.Clear();

                btnStart.Text = "Start";
                rbServer.Enabled = rbClient.Enabled = true;
            }
            catch { }
        }

        private async void BtnSend_Click(object sender, EventArgs e)
        {
            string msg = txtMessage.Text.Trim();
            if (msg == "") return;

            var obj = new
            {
                type = "chat",
                from = txtUsername.Text,
                to = "ALL",
                message = msg
            };

            foreach (var c in clients.Values)
                await SendJsonAsync(c, obj);

            Log("Me: " + msg);
            txtMessage.Clear();
        }

        void Log(string msg)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(Log), msg);
                return;
            }
            logBox.AppendText(msg + Environment.NewLine);
            // auto-scroll to end
            logBox.SelectionStart = logBox.Text.Length;
            logBox.ScrollToCaret();
        }

        void Error(string where, Exception ex)
        {
            Log($"[ERROR] {where}: {ex.Message}");
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            StopAll();
            base.OnFormClosing(e);
        }

        static class FileTransfer
        {
            public static async Task<int> ReadExactlyAsync(Stream s, byte[] buffer, int offset, int count, CancellationToken token)
            {
                int total = 0;
                while (total < count)
                {
                    int r = await s.ReadAsync(buffer, offset + total, count - total, token);
                    if (r == 0) return total;
                    total += r;
                }
                return total;
            }
        }
    }
}
