using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RealtimeChatShared;

namespace ServerApp
{
    public class ServerManager
    {
        TcpListener? listener;
        TcpClient? client;
        NetworkStream? stream;
        Thread? listenerThread;

        public void Start(int port, Action<string> log)
        {
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            log($"[Server] Listening on port {port}");

            listenerThread = new Thread(async () =>
            {
                try
                {
                    client = listener.AcceptTcpClient();
                    log("[Server] Client connected");
                    stream = client.GetStream();

                    // Bắt đầu vòng lặp nhận dữ liệu (text hoặc file)
                    await ReceiveLoopAsync(stream, log, CancellationToken.None);
                }
                catch (Exception ex)
                {
                    log($"[ERROR] Listener: {ex.Message}");
                }
            });
            listenerThread.IsBackground = true;
            listenerThread.Start();
        }

        private async Task ReceiveLoopAsync(NetworkStream ns, Action<string> log, CancellationToken token)
        {
            try
            {
                var buf = new byte[4];
                var reader = new StreamReader(ns, Encoding.UTF8);

                while (!token.IsCancellationRequested)
                {
                    if (!ns.CanRead) break;

                    int peek = ns.ReadByte();
                    if (peek == -1) break;

                    // trả byte về lại stream (nếu có)
                    if (ns.CanSeek) ns.Seek(-1, SeekOrigin.Current);
                    else { /* bỏ qua vì NetworkStream không Seek được */ }

                    int bytesRead = await ns.ReadAsync(buf, 0, 4, token);
                    if (bytesRead < 4)
                    {
                        string? textMsg = await reader.ReadLineAsync();
                        if (string.IsNullOrWhiteSpace(textMsg)) break;
                        log("[Client] " + textMsg);
                        continue;
                    }

                    int headerLen = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(buf, 0));
                    if (headerLen <= 0 || headerLen > 10_000_000)
                    {
                        string line = Encoding.UTF8.GetString(buf, 0, bytesRead) + (await reader.ReadLineAsync());
                        log("[Client] " + line.Trim());
                        continue;
                    }

                    // Đọc header JSON
                    byte[] headerBuf = new byte[headerLen];
                    await FileTransfer.ReadExactlyAsync(ns, headerBuf, 0, headerLen, token);
                    string headerJson = Encoding.UTF8.GetString(headerBuf);

                    // Kiểm tra loại file
                    if (headerJson.Contains("\"Type\":\"FILE\""))
                    {
                        log("[INFO] Receiving file...");
                        string saved = await FileTransfer.ReceiveFileAsync(
                            ns,
                            headerJson,
                            Path.Combine(AppContext.BaseDirectory, "received"),
                            token
                        );
                        log($"[OK] File saved: {Path.GetFileName(saved)}");

                        // Nếu là ảnh thì tự mở
                        try
                        {
                            string ext = Path.GetExtension(saved).ToLowerInvariant();
                            if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".gif" || ext == ".bmp")
                            {
                                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(saved)
                                {
                                    UseShellExecute = true
                                });
                            }
                        }
                        catch { /* bỏ qua lỗi mở ảnh */ }
                    }
                    else
                    {
                        log("[MSG] " + headerJson);
                    }
                }
            }
            catch (Exception ex)
            {
                log($"[ERROR] ReceiveLoop: {ex.Message}");
            }
        }

        public async Task SendTextAsync(string msg)
        {
            try
            {
                if (client == null || !client.Connected) return;
                var ns = client.GetStream();
                byte[] data = Encoding.UTF8.GetBytes(msg + "\n"); // ✅ newline để StreamReader đọc được
                await ns.WriteAsync(data, 0, data.Length);
                await ns.FlushAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] SendTextAsync: {ex.Message}");
            }
        }

        public async Task SendFileAsync(string filePath, Action<string> log)
        {
            try
            {
                if (client == null || stream == null)
                {
                    log("[Server] No client connected.");
                    return;
                }

                log("[Server] Sending file: " + Path.GetFileName(filePath));
                await FileTransfer.SendFileAsync(stream, filePath);
                log("[Server] File sent successfully.");
            }
            catch (Exception ex)
            {
                log($"[ERROR] SendFile: {ex.Message}");
            }
        }

        public void Stop(Action<string> log)
        {
            try
            {
                listener?.Stop();
                client?.Close();
                stream?.Close();
                log("[Server] Stopped.");
            }
            catch (Exception ex)
            {
                log("[ERROR] Stop: " + ex.Message);
            }
        }
    }
}
