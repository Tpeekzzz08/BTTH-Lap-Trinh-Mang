﻿using System;
using System.IO;
using System.Net.Sockets;

namespace ChatClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap IP may server (vd 192.168.1.50): ");
            string serverIP = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(serverIP))
            {
                Console.WriteLine("IP khong hop le.");
                return;
            }

            int port = 1308;

            while (true)
            {
                Console.Write("Nhap lenh (calc/check/exit): ");
                string request = Console.ReadLine() ?? "";
                if (request.Equals("exit", StringComparison.OrdinalIgnoreCase)) break;

                try
                {
                    using (var socket = new TcpClient())
                    {
                        socket.Connect(serverIP, port);

                        using (var stream = socket.GetStream())
                        using (var reader = new StreamReader(stream))
                        using (var writer = new StreamWriter(stream) { AutoFlush = true })
                        {
                            writer.WriteLine(request);

                            string response = reader.ReadLine() ?? "(khong co phan hoi)";
                            Console.WriteLine($"Server tra: {response}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Khong ket noi duoc: {ex.Message}");
                }
            }
        }
    }
}
