﻿using System;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ChatServer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int port = 1308;

            // Lắng nghe trên mọi card mạng: localhost + LAN + Wi-Fi/Ethernet
            TcpListener listener = new TcpListener(IPAddress.Any, port);
            listener.Start();

            Console.WriteLine($"Server started on port {port}...");
            Console.WriteLine("IP LAN cua may server (dua IP nay cho Client):");
            foreach (var ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    Console.WriteLine($" - {ip}");
            }

            Console.WriteLine("Dang cho client ket noi...");

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();

                Thread t = new Thread(HandleClient);
                t.IsBackground = true;
                t.Start(client);
            }
        }

        static void HandleClient(object obj)
        {
            TcpClient client = (TcpClient)obj;

            string clientIP = client.Client.RemoteEndPoint?.ToString() ?? "Unknown";
            Console.WriteLine($"Client ket noi: {clientIP}");

            try
            {
                // Timeout để tránh treo nếu client im lặng / treo
                client.ReceiveTimeout = 15000; // 15s
                client.SendTimeout = 15000;

                using (client)
                using (NetworkStream stream = client.GetStream())
                using (StreamReader reader = new StreamReader(stream))
                using (StreamWriter writer = new StreamWriter(stream) { AutoFlush = true })
                {
                    // Nếu client của bạn “mỗi lần gửi lệnh tạo 1 kết nối rồi đóng”
                    // thì vòng lặp này sẽ đọc 1 dòng, trả lời, sau đó ReadLine() sẽ null và thoát.
                    while (true)
                    {
                        string request = reader.ReadLine();
                        if (request == null) break; // client đóng kết nối

                        request = request.Trim();
                        if (request.Length == 0)
                        {
                            writer.WriteLine("Yeu cau rong!");
                            continue;
                        }

                        Console.WriteLine($"[{clientIP}] Gui: {request}");

                        string response = ProcessRequest(request);
                        writer.WriteLine(response);
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine($"Client {clientIP} mat ket noi / timeout.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Loi voi client {clientIP}: {ex.Message}");
            }
        }

        static string ProcessRequest(string request)
        {
            // calc: calc 2+3*5
            if (request.StartsWith("calc", StringComparison.OrdinalIgnoreCase))
            {
                string expr = request.Length > 4 ? request.Substring(4).Trim() : "";

                if (expr.Length == 0) return "Sai cu phap. Vi du: calc 2+3*5";

                try
                {
                    double result = Evaluate(expr);
                    return $"Ket qua: {result}";
                }
                catch
                {
                    return "Loi phep tinh!";
                }
            }

            // check: check 7  / check7 (đều được)
            if (request.StartsWith("check", StringComparison.OrdinalIgnoreCase))
            {
                string tail = request.Length > 5 ? request.Substring(5).Trim() : "";
                if (!int.TryParse(tail, out int number))
                    return "Sai cu phap. Vi du: check 7";

                if (IsPrime(number)) return $"{number} la so nguyen to";
                if (number % 2 == 0) return $"{number} la so chan";
                return $"{number} la so le";
            }

            return "Lenh khong hop le! (calc/check). Vi du: calc 2+3 hoặc check 7";
        }

        static double Evaluate(string expr)
        {
            var dt = new DataTable();
            return Convert.ToDouble(dt.Compute(expr, ""));
        }

        static bool IsPrime(int n)
        {
            if (n < 2) return false;
            int limit = (int)Math.Sqrt(n);
            for (int i = 2; i <= limit; i++)
                if (n % i == 0) return false;
            return true;
        }
    }
}
